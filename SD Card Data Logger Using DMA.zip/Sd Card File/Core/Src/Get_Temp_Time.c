/*
 * Get_Temp_Time.c
 *
 *  Created on: Jan 7, 2026
 *      Author: Vaishnav
 */
#include "main.h"
#include "Get_Temp_Time.h"
#include <stdio.h>
#include "sd_functions.h"

uint16_t adc_temp_dma;

//float read_internal_temp(void) {
//    // Start ADC (configure in CubeMX: ADC1 CH16, continuous mode)
//	// CRITICAL: Wake up temp sensor (10µs delay needed)
////	    SET_BIT(ADC1->CCR, ADC_CCR_TSVREFE);
////	    HAL_Delay(1);  // >10µs wait
//	char buff[30];
//    HAL_ADC_Start(&hadc1);
//    HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
//    uint32_t adc_raw = adc_temp_dma;
//
//    HAL_ADC_Stop(&hadc1);
//
//    // F411 DATASHEET values (Table 71)
//        // Use factory calibration for accuracy
//        uint16_t vref_cal = (*(uint16_t*)0x1FFF7A0A);  // VREFINT at 30°C
//        uint16_t temp_cal_30c = (*(uint16_t*)0x1FFF7A2A);  // TSENSE at 30°C
//
//        // Convert raw ADC to voltage (mV)
//        float v_sense_mv = (adc_raw * 3300.0f) / 4096.0f;
//
//        // Datasheet typical values if calibration fails
//        float temp_typical = 30.0f + (v_sense_mv - 760.0f) / 4.3f;
//
//        sprintf(buff, "%.2f°C \r\n", temp_typical);
//        send_uart(buff);
//
//        return temp_typical;
//}
char* get_timestamp(char* buf) {
    // Use RTC (configure RTC in CubeMX) to set time accordingly
    RTC_TimeTypeDef time;

    HAL_RTC_GetTime(&hrtc, &time, RTC_FORMAT_BIN);


    sprintf(buf, "%02d:%02d:%02d\r\n", time.Hours, time.Minutes, time.Seconds);
    return buf;
}
char* get_datestamp(char* buf1){
	// Use RTC (configure RTC in CubeMX) to set time accordingly
	RTC_DateTypeDef date;
	HAL_RTC_GetDate(&hrtc, &date, RTC_FORMAT_BIN);
	date.Year = 2000 + date.Year;
	sprintf(buf1, "%04d-%02d-%02d \r\n", date.Year, date.Month, date.Date);
	return buf1;

}
//uint32_t test_raw_adc(void) {
////    SET_BIT(ADC1->CCR, ADC_CCR_TSVREFE);
////    HAL_Delay(1);
//	char* buff;
//    HAL_ADC_Start(&hadc1);
//    HAL_ADC_PollForConversion(&hadc1, 1000);
//    uint32_t raw = HAL_ADC_GetValue(&hadc1);
//
//   // CLEAR_BIT(ADC1->CCR, ADC_CCR_TSVREFE);
//
//    sprintf(buff, "Raw ADC: %lu\r\n", raw);  // Should be ~1500-2500
//    send_uart(buff);
//
//    return raw;
//}
float read_internal_temp_dma(void) {
    // same v_sense_mv and temp_typical math
    	char buff[30];
//        HAL_ADC_Start(&hadc1);
//        HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
        uint32_t adc_raw = adc_temp_dma;	// Latest DMA -> ADC Value Update
        sprintf(buff, "RAW:%lu \r\n", adc_raw);  // Should change ~1600-2200! // Not Then ADC & DMA Crash 
        send_uart(buff);
//        HAL_ADC_Stop(&hadc1);

        // F411 DATASHEET values (Table 71)
        // Use factory calibration for accuracy
            uint16_t vref_cal = (*(uint16_t*)0x1FFF7A0A);  // VREFINT at 3.0V
            uint16_t temp_cal_30c = (*(uint16_t*)0x1FFF7A2A);  // TSENSE at 30°C

            // Convert raw ADC to voltage (mV)
            float v_sense_mv = (adc_raw * 3300.0f) / 4096.0f;

            // Datasheet typical values if calibration fails
            float temp_typical = 30.0f + (v_sense_mv - 760.0f) / 4.3f;

            sprintf(buff, " RAW ADC = %4lu %.2f°C \r\n",adc_raw, temp_typical);
            send_uart(buff);

            return temp_typical;
}

