/*
 * Get_Temp_Time.h
 *
 *  Created on: Jan 7, 2026
 *      Author: Vaishnav
 */

#ifndef INC_GET_TEMP_TIME_H_
#define INC_GET_TEMP_TIME_H_

#include "main.h"
#include "stm32f4xx_hal.h"

extern ADC_HandleTypeDef hadc1;

extern RTC_HandleTypeDef hrtc;
// STM32F411 params (from datasheet)
#define TEMP_AVG_SLOPE     0.0045f   // mV/°C
#define TEMP_25C_VOLTAGE   760.0f    // mV at 25°C
#define VREFINT_CAL        (*(uint16_t*)0x1FFF7A0A)  // Factory Vrefint calibration

// Temperature Function Prototype
//float read_internal_temp(void);
float read_internal_temp_dma(void);
// Time Function Prototype
char* get_timestamp(char* buf);
char* get_datestamp(char* buf1);
#endif /* INC_GET_TEMP_TIME_H_ */
