/*
 * sd_benchmark.h
 *
 *  Created on: Jan 7, 2026
 *      Author: Vaishnav
 */
#ifndef __SD_BENCHMARK_H__
#define __SD_BENCHMARK_H__

#include <stdint.h>

void sd_benchmark(void);

#endif // __SD_BENCHMARK_H__
