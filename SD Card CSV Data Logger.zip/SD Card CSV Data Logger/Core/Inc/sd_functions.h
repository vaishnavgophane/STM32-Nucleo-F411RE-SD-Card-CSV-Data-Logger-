/*
 * sd_functions.h
 *
 *  Created on: Jan 7, 2026
 *      Author: Vaishnav
 */
#ifndef __SD_FUNCTIONS_H__
#define __SD_FUNCTIONS_H__

#include "fatfs.h"
#include <stdint.h>

extern char sd_path[];

// UART print
void send_uart (char *string);

// Mount and unmount
int sd_mount(void);
int sd_unmount(void);

// Basic file operations
int sd_write_file(const char *filename, const char *text);
int sd_append_file(const char *filename, const char *text);
int sd_read_file(const char *filename, char *buffer, UINT bufsize, UINT *bytes_read);
int sd_delete_file(const char *filename);
int sd_rename_file(const char *oldname, const char *newname);


// Directory handling
FRESULT sd_create_directory(const char *path);
void sd_list_directory_recursive(const char *path, int depth);
void sd_list_files(void);

// Space information
int sd_get_space_kb(void);

//csv File operations
// CSV Record structure
typedef struct CsvRecord {
	int index;
    int value;
} CsvRecord;
typedef struct {
    char timestamp[20];  // " 11:03:45 "
    char datestamp[20];		// " 2026-01-07 "
    float temp;        // Temperature in °C
} TempRecord;
//int csv_buffer[] = {0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09};
//  For CSV
int sd_read_csv(const char *filename, CsvRecord *records, int max_records, int *record_count);
int sd_write_csv_buffer(const char *filename1);
#endif // __SD_FUNCTIONS_H__
