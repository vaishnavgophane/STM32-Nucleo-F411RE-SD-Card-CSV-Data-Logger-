/*
 * sd_diskio.h
 *
 *  Created on: Jan 3, 2026
 *      Author: Administrator
 */
#include "sd_spi.h"
#include <stdio.h>

#ifndef INC_SD_DISKIO_H_
#define INC_SD_DISKIO_H_


DSTATUS SD_initialize (BYTE pdrv);
DSTATUS SD_status     (BYTE pdrv);
DRESULT SD_read       (BYTE pdrv, BYTE *buff, DWORD sector, UINT count);
DRESULT SD_write      (BYTE pdrv, const BYTE *buff, DWORD sector, UINT count);
DRESULT SD_ioctl      (BYTE pdrv, BYTE cmd, void *buff);

#endif /* INC_SD_DISKIO_H_ */
